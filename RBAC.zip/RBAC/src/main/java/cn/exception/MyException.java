package cn.exception;

public class MyException {
}
