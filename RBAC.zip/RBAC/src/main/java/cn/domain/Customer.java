package cn.domain;

public class Customer {
    private Long id;
    private String name;
    private Long age;
    private String gender;
    private String tel;
    private String qq;
    private Dictionaryitem job;
    private Dictionaryitem source;
    private Employee seller;
    private String status;

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", gender=" + gender +
                ", tel='" + tel + '\'' +
                ", qq='" + qq + '\'' +
                ", job=" + job +
                ", source=" + source +
                ", seller=" + seller +
                ", status=" + status +
                '}';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getAge() {
        return age;
    }

    public void setAge(Long age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(Long g) {

        if (g==0)
        {
            this.gender = "男";
        }
        else {
            this.gender = "女";
        }

    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public Dictionaryitem getJob() {
        return job;
    }

    public void setJob(Dictionaryitem job) {
        this.job = job;
    }

    public Dictionaryitem getSource() {
        return source;
    }

    public void setSource(Dictionaryitem source) {
        this.source = source;
    }

    public Employee getSeller() {
        return seller;
    }

    public void setSeller(Employee seller) {
        this.seller = seller;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(Long s) {
        if(s==-1L)
            this.status="全部";
        else if (s==0)
            this.status="潜在客户";
        else if (s==1)
            this.status="正式客户";
        else if (s==2)
            this.status="资源池客户";
        else if (s==3)
            this.status="失败客户";
        else if (s==4)
            this.status="流失客户";
        else
            this.status="什么都不是客户客户";
    }
}
