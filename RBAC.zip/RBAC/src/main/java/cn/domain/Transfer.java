package cn.domain;

import java.util.Date;

public class Transfer {
    private  Long id;
    private Customer customer;
    private Employee operator;
//    private Date operate_time;
    private Date operateTime;
    private Employee oldSeller;
    private Employee newSeller;
    private String reason;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Employee getOperator() {
        return operator;
    }

    public void setOperator(Employee operator) {
        this.operator = operator;
    }

//    public Date getOperate_time() {
//        return operate_time;
//    }
//
//    public void setOperate_time(Date operate_time) {
//        this.operate_time = operate_time;
//    }

    public Date getOperateTime() {
        return operateTime;
    }

    public void setOperateTime(Date operateTime) {
        this.operateTime = operateTime;
    }

    public Employee getOldSeller() {
        return oldSeller;
    }

    public void setOldSeller(Employee oldSeller) {
        this.oldSeller = oldSeller;
    }

    public Employee getNewSeller() {
        return newSeller;
    }

    public void setNewSeller(Employee newSeller) {
        this.newSeller = newSeller;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
