package cn.web.controller;

import cn.anno.RequiredPermission;
import cn.domain.Department;
import cn.domain.Employee;
import cn.domain.Role;
import cn.query.EmployeeQueryObject;
import cn.query.JSONResult;
import cn.query.QueryObject;
import cn.service.DepartmentService;
import cn.service.EmployeeService;
import cn.service.RoleService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private RoleService roleService;

    @RequestMapping("/list")
    @RequiredPermission({"员工列表权限","cn.web.controller.EmployeeController.list"})
    public String list(Model model, @ModelAttribute("qo") EmployeeQueryObject qo){
        PageInfo pageInfo = employeeService.findAll(qo);

        List<Department> departments = departmentService.listAll();

        model.addAttribute("depts",departments);
        model.addAttribute("result", pageInfo);

        return "employee/list";
    }

    @RequestMapping("/delete")
    @RequiredPermission({"员工删除权限","cn.web.controller.EmployeeController.delete"})
    @ResponseBody //响应对象数据
    public JSONResult delete(long id){
//        try {
//            employeeService.deleteById(id);
//            return new JSONResult();
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new JSONResult().mark("删除失败！");
//        }
        employeeService.deleteById(id);
            return new JSONResult();
    }

    @RequestMapping("/input")
    @RequiredPermission({"员工添加/编辑链接权限","cn.web.controller.EmployeeController.input"})
    public String input(Model model,Long id){
        List<Department> departments = departmentService.listAll();
        model.addAttribute("depts",departments);

        if (id!=null){
            model.addAttribute("entity",employeeService.seleteById(id));
        }

        List<Role> roles = roleService.listAll();
        model.addAttribute("roles",roles);

        return "/employee/input";
    }

    @RequestMapping("/saveOrUpdate")
    @RequiredPermission({"员工添加/编辑权限","cn.web.controller.EmployeeController.saveOrUpdate"})
    public String saveOrUpdate(Employee employee , Long ids[]) {


        employeeService.saveOrUpdate(employee,ids);

        return "redirect:/employee/list";
    }
}
