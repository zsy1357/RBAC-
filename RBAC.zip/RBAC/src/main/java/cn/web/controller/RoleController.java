package cn.web.controller;

import cn.anno.RequiredPermission;
import cn.domain.Permission;
import cn.domain.Role;
import cn.query.JSONResult;
import cn.query.QueryObject;
import cn.service.PermissionService;
import cn.service.RoleService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/role")
public class RoleController {
    @Autowired
    private RoleService roleService;
    @Autowired
    private PermissionService permissionService;

    @RequestMapping("/list")
    @RequiredPermission({"角色列表权限","cn.web.controller.RoleController.list"})
    public String list(Model model, @ModelAttribute("qo") QueryObject qo){
        PageInfo pageInfo = roleService.findAll(qo);
        model.addAttribute("result",pageInfo);
        return "role/list";
    }

    @RequestMapping("/delete")
    @RequiredPermission({"角色删除权限","cn.web.controller.RoleController.delete"})
    @ResponseBody //响应对象数据
    public JSONResult delete(long id){
        try {
            roleService.deleteById(id);
            return new JSONResult();
        } catch (Exception e) {
            e.printStackTrace();
            return new JSONResult().mark("删除失败！");
        }
    }

    @RequestMapping("/input")
    @RequiredPermission({"角色添加/删除链接权限","cn.web.controller.RoleController.input"})
    public String input(Model model,Long id){
        if (id!=null){
            model.addAttribute("entity",roleService.seleteById(id));
        }
        List<Permission> permissions = permissionService.listAll();
        model.addAttribute("permissions",permissions);

        return "/role/input";
    }

    @RequestMapping("/saveOrUpdate")
    @RequiredPermission({"角色添加/删除权限","cn.web.controller.RoleController.saveOrUpdate"})
    public String saveOrUpdate(Role role , Long ids[]) {

        roleService.saveOrUpdate(role ,ids);

        return "redirect:/role/list";
    }
}
