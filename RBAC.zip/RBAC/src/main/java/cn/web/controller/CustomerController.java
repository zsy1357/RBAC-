package cn.web.controller;

import cn.anno.RequiredPermission;
import cn.domain.*;
import cn.query.CustomerQueryObject;
import cn.query.EmployeeQueryObject;
import cn.query.QueryObject;
import cn.service.CustomerService;
import cn.service.DictionaryitemService;
import cn.service.EmployeeService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/customer")
public class CustomerController {


    @Autowired
    CustomerService customerService;
    @Autowired
    DictionaryitemService dictionaryitemService;
    @Autowired
    EmployeeService employeeService;
    @RequestMapping("/list")
    public String list(Model model, @ModelAttribute("qo") CustomerQueryObject qo){
        PageInfo pageInfo = customerService.findAll(qo);

        List<Employee> employees = employeeService.listAll();
        model.addAttribute("sellers",employees);
        model.addAttribute("result", pageInfo);
        return "customer/list";
    }

    @RequestMapping("/failList")
    public String failList(Model model, @ModelAttribute("qo") CustomerQueryObject qo){
        PageInfo pageInfo = customerService.findAll2(qo);

        List<Employee> employees = employeeService.listAll2();
        System.out.println(employees);
        model.addAttribute("sellers",employees);
        model.addAttribute("result", pageInfo);
        return "customerFail/list";
    }

    @RequestMapping("/formalList")
    public String formalList(Model model, @ModelAttribute("qo") CustomerQueryObject qo){
        PageInfo pageInfo = customerService.findAll3(qo);

        List<Employee> employees = employeeService.listAll3();
        System.out.println(employees);
        model.addAttribute("emps",employees);
        model.addAttribute("result", pageInfo);
        return "customerFormal/list";
    }

//    @RequestMapping("/lossList")
//    public String lossList(Model model, @ModelAttribute("qo") CustomerQueryObject qo){
//        PageInfo pageInfo = customerService.findAll0(qo,4L);
//
//        List<Employee> employees = employeeService.listAll0(4L);
//        System.out.println(employees);
//        model.addAttribute("emps",employees);
//        model.addAttribute("result", pageInfo);
//        return "customerLoss/list";
//    }

    @RequestMapping("/lossList")
    public String lossList(Model model, @ModelAttribute("qo") CustomerQueryObject qo){

        PageInfo pageInfo = customerService.findAll4(qo);

        List<Employee> employees = employeeService.listAll4();
        System.out.println(employees);
        model.addAttribute("emps",employees);
        model.addAttribute("result", pageInfo);
        return "customerLoss/list";
    }
}
