package cn.web.controller;

import cn.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.query.JSONResult;
@Controller
@RequestMapping("/emp")
public class LoginController {

    @Autowired
    private EmployeeService employeeService;

    @RequestMapping("/login")
    @ResponseBody
    public JSONResult employeelogin(String username, String password, Model model) {
//        try {
            employeeService.checkNameAndPwd(username, password);
            return new JSONResult();

//        } catch (Exception e) {
//            e.printStackTrace();
//            return new JSONResult().mark(e.getMessage());
//        }
    }
}
