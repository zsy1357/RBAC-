package cn.web.controller;

import cn.anno.RequiredPermission;
import cn.query.JSONResult;
import cn.query.QueryObject;
import cn.service.PermissionService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/permission")
public class PermissionController {
    @Autowired
    private PermissionService permissionService;

    @RequestMapping("/list")
    @RequiredPermission({"权限列表权限","cn.web.controller.PermissionController.list"})
    public String list(Model model, @ModelAttribute("qo") QueryObject qo){
        PageInfo pageInfo = permissionService.findAll(qo);
        model.addAttribute("result",pageInfo);
        return "permission/list";
    }

    @RequestMapping("/reload")
    @RequiredPermission({"权限重载权限","cn.web.controller.PermissionController.reload"})
    public String reload(){

        permissionService.reload();

        return "redirect:/permission/list";
    }

    @RequestMapping("/delete")
    @RequiredPermission({"权限删除权限","cn.web.controller.PermissionController.delete"})
    @ResponseBody //响应对象数据
    public JSONResult delete(long id){
        try {
            permissionService.deleteById(id);
            return new JSONResult();
        } catch (Exception e) {
            e.printStackTrace();
            return new JSONResult().mark("删除失败！");
        }
    }
}
