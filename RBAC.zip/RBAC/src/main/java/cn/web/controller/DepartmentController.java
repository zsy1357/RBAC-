package cn.web.controller;

import cn.anno.RequiredPermission;
import cn.domain.Department;
import cn.query.JSONResult;
import cn.query.QueryObject;
import cn.service.DepartmentService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import java.util.List;

@Controller
@RequestMapping("/department")
public class DepartmentController {
    @Autowired
    private DepartmentService departmentService;

    @RequestMapping("/list")
    @RequiredPermission({"部门列表权限","cn.web.controller.DepartmentController.list"})
    public String list(Model model,@ModelAttribute("qo") QueryObject qo){
//        List <Department> list= departmentService.findAll();
        PageInfo pageInfo = departmentService.findAll(qo);
        model.addAttribute("result",pageInfo);
        return "department/list";
    }

    @RequestMapping("/delete")
    @RequiredPermission({"部门删除权限","cn.web.controller.DepartmentController.delete"})
    @ResponseBody //响应对象数据
    public JSONResult delete(long id){
        try {
            departmentService.deleteById(id);
            return new JSONResult();
        } catch (Exception e) {
            e.printStackTrace();
            return new JSONResult().mark("删除失败！");
        }
    }

    @RequestMapping("/input")
    @RequiredPermission({"部门插入/更新表达链接权限","cn.web.controller.DepartmentController.input"})
    public String input(Model model,Long id){
        if (id!=null){
            model.addAttribute("entity",departmentService.seleteById(id));
        }
        return "department/input";
    }

    @RequestMapping("/saveOrUpdate")
    @RequiredPermission({"部门插入/更新权限","cn.web.controller.DepartmentController.saveOrUpdate"})
    public String saveOrUpdate(Department department) {

        departmentService.saveOrUpdate(department);

        return "redirect:/department/list";
    }

}
