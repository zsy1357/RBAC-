package cn.web.controller;

import cn.anno.RequiredPermission;
import cn.query.QueryObject;
import cn.query.TranferQueryObject;
import cn.service.DepartmentService;
import cn.service.TransferService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/customerTransfer")
public class TransferController {
    @Autowired
    private TransferService transferService;

    @RequestMapping("/list")
    public String list(Model model, @ModelAttribute("qo") TranferQueryObject qo){
        PageInfo pageInfo = transferService.findAll(qo);
        model.addAttribute("result",pageInfo);
        return "customerTransfer/list";
    }
}
