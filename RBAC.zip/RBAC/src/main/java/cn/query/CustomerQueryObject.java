package cn.query;

import cn.domain.Employee;

public class CustomerQueryObject extends QueryObject{
    private  String keyword;
    private Long status=-1L;
    private Long sellerId=-1L;


    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }
}
