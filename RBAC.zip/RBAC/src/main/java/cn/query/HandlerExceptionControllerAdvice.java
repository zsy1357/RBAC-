package cn.query;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
   public class HandlerExceptionControllerAdvice {
  @ExceptionHandler(DisableException.class)
  @ResponseBody
  public JSONResult error(DisableException ex) {
      return new JSONResult().mark(ex.getMessage());
  }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public JSONResult error(Exception ex) {
        return new JSONResult().mark("凉凉！！！");
    }
}