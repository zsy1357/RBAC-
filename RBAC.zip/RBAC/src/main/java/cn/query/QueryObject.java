package cn.query;

public class QueryObject {

    private int currentPage =1;  //当前页
    private int pageSize = 4; // 每页显示几条数据

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "QueryObject{" +
                "currentPage=" + currentPage +
                ", pageSize=" + pageSize +
                '}';
    }


}
