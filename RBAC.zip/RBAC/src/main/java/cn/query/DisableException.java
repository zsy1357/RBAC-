package cn.query;

public class DisableException extends RuntimeException{


    public DisableException(String message ) {
        super(message);

    }
}
