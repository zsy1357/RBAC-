package cn.util;

import cn.query.DisableException;
import org.junit.Assert;

public class AssertUtil {

    private AssertUtil() {
    }

    /**
     * 判断传入value值是否有值
     *
     * @param value
     * @param msg
     * @return
     */
    public static void assertString(String value, String msg) {
        if (value == null || "".equals(value.trim())) {
            throw new DisableException(msg);
        }
    }

    /**
     * 判断v1 跟 v2 是否一致
     *
     * @param password
     * @param rpassword
     * @param msg
     */
    public static void assertEquals(String password, String rpassword, String msg) {

        if (password == null || rpassword == null) {
            throw new DisableException("传入判断参数不能为空");
        }

        if (!password.equals(rpassword)) {
            throw new DisableException(msg);
        }

    }

    public static boolean hashLength(String value) {

        return value != null && value.trim().length() > 0;
    }

    public static boolean hashLength(Long value) {
        return value != null ;
    }


}
