package cn.mapper;

import cn.domain.Transfer;
import cn.query.QueryObject;

import java.util.List;

public interface TransferMapper {

    List<Transfer> findAll(QueryObject qo);
}
