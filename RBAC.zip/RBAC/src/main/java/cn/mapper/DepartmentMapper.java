package cn.mapper;

import cn.domain.Department;

import java.util.List;

public interface DepartmentMapper {

    List<Department> findAll ();

    void deleteById(long id);

    int insert(Department department);

    int updateByPrimaryKey(Department department);

//    Department update(Long id);

    Department seleteById(Long id);

    List<Department> listAll();

}
