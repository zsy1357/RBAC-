package cn.mapper;

import cn.domain.Employee;
import cn.domain.Role;
import cn.query.QueryObject;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EmployeeMapper {
    List<Employee> findAll(QueryObject qo);

    void deleteById(long id);

    Object seleteById(Long id);

    void updateByPrimaryKey(Employee employee);

    void insert(Employee employee);

    void deleteRelation(Long id);
//Mybatis不允许传入多个参数，因此，只能封装成对象或做成容器
    void insertRelation(@Param("empId")Long empId,@Param("roleId")Long roleId);

    Employee selectByNameAndPwd(@Param("username") String username, @Param("password") String password);

    List<Employee> listAll(Long id);

    List<Employee> listAll2(Long id);

    List<Employee> listAll3(Long id);

    List<Employee> listAll0(@Param("id") Long id,@Param("sId") Long sId);

    List<Employee> listAll4(Long id);
}
