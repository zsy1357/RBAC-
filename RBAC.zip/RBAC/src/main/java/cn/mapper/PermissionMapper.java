package cn.mapper;

import cn.domain.Permission;

import java.util.List;

public interface PermissionMapper {
    List<Permission> findAll();

    void deleteAll();

    void insert(Permission permission);

    void deleteById(long id);

    List<Permission> selectPermissionsByEmpId(Long empId);
}
