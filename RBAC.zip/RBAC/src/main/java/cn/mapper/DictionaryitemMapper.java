package cn.mapper;

import cn.domain.Dictionaryitem;

import java.util.List;

public interface DictionaryitemMapper {
    List<Dictionaryitem> listAll();
}
