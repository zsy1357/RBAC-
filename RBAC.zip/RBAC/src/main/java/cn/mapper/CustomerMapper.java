package cn.mapper;

import cn.domain.Customer;
import cn.query.CustomerQueryObject;
import cn.query.QueryObject;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CustomerMapper {
    List<Customer> findAll(QueryObject qo);

    List<Customer> findAll2(CustomerQueryObject qo);

    List<Customer> findAll3(CustomerQueryObject qo);

    List<Customer> findAll0(@Param("qo") CustomerQueryObject qo, @Param("sId") Long sId);

    List<Customer> findAll4(CustomerQueryObject qo);
}
