package cn.mapper;

import cn.domain.Role;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RoleMapper {
    List<Role> findAll ();

    void deleteById(long id);

    Object seleteById(Long id);

    void updateByPrimaryKey(Role role);

    void insert(Role role);

    void deleteRelation(Long id);
    //Mybatis不允许传入多个参数，因此，只能封装成对象或做成容器
    void insertRelation(@Param("roleId")Long roleId, @Param("pId")Long pId);

    Long findId();
}
