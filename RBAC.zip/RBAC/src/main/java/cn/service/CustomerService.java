package cn.service;

import cn.query.CustomerQueryObject;
import cn.query.QueryObject;
import com.github.pagehelper.PageInfo;

public interface CustomerService {
    PageInfo findAll(QueryObject qo);

    PageInfo findAll2(CustomerQueryObject qo);

    PageInfo findAll3(CustomerQueryObject qo);

    PageInfo findAll0(CustomerQueryObject qo, Long sId);

    PageInfo findAll4(CustomerQueryObject qo );
}
