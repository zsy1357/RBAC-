package cn.service;

import cn.domain.Dictionaryitem;

import java.util.List;

public interface DictionaryitemService {
    List<Dictionaryitem> listAll();
}
