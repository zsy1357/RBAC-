package cn.service;

import cn.query.QueryObject;
import com.github.pagehelper.PageInfo;

public interface TransferService {
    PageInfo findAll(QueryObject qo);
}
