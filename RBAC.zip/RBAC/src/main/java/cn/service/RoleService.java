package cn.service;

import cn.domain.Role;
import cn.query.QueryObject;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface RoleService {
     PageInfo findAll(QueryObject qo);

     void deleteById(long id);

    Object seleteById(Long id);

    void saveOrUpdate(Role role , Long ids[]);

    List<Role> listAll();
}
