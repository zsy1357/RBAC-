package cn.service;

import cn.domain.Permission;
import cn.query.QueryObject;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface PermissionService {
    PageInfo findAll(QueryObject qo);

    void reload();

    void deleteById(long id);

    List<Permission> listAll();
}
