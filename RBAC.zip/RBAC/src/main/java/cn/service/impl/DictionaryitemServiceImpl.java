package cn.service.impl;

import cn.domain.Department;
import cn.domain.Dictionaryitem;
import cn.mapper.DictionaryitemMapper;
import cn.service.DictionaryitemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DictionaryitemServiceImpl implements DictionaryitemService {
    @Autowired
    DictionaryitemMapper dictionaryitemMapper;
    @Override
    public List<Dictionaryitem> listAll() {
        List<Dictionaryitem> dictionaryitems = dictionaryitemMapper.listAll();
        return dictionaryitems;
    }
}
