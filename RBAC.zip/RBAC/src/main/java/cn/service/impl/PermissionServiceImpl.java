package cn.service.impl;

import cn.anno.RequiredPermission;
import cn.domain.Permission;
import cn.mapper.PermissionMapper;
import cn.query.QueryObject;
import cn.service.PermissionService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;
import java.util.Map;


@Service
public class PermissionServiceImpl implements PermissionService{

    @Autowired
    PermissionMapper permissionMapper;


    @Override
    public PageInfo findAll(QueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Permission> permission =  permissionMapper.findAll();

        return new  PageInfo(permission);
    }

    @Autowired
    private ApplicationContext ctx;
    @Override
    public void reload() {
        //清理权限表的数据
        permissionMapper.deleteAll();
        //获取所有的Controller注解
        Map<String,Object> beansWithAnnotation= ctx.getBeansWithAnnotation(Controller.class);
        Collection<Object> controllers = beansWithAnnotation.values();
        for (Object controller : controllers){
            Method[] methods = controller.getClass().getDeclaredMethods();
            for (Method method : methods) {
                if (method.isAnnotationPresent(RequiredPermission.class)) {
                    // 从所有的方法上获取RequestPermission注解
                    RequiredPermission requestPermission = method.getAnnotation(RequiredPermission.class);
                    // 从注解中获取 权限的名称和表达式
                    String[] strings = requestPermission.value();
                    String name = strings[0];
                    String exception = strings[1];
                    Permission permission = new Permission();
                    permission.setName(name);
                    permission.setExpression(exception);
                    // 把权限信息保存到数据库中
                    permissionMapper.insert(permission);
                }
            }
        }
    }

    @Override
    public void deleteById(long id) {
        permissionMapper.deleteById(id);
    }

    @Override
    public List<Permission> listAll() {
        return permissionMapper.findAll();
    }
}
