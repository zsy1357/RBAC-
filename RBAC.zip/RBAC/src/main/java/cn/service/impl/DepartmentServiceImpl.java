package cn.service.impl;

import cn.domain.Department;
import cn.mapper.DepartmentMapper;
import cn.query.QueryObject;
import cn.service.DepartmentService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {
    @Autowired
    DepartmentMapper departmentMapper;
    @Override
    public PageInfo findAll(QueryObject queryObject)
    {
        // PageHelper 插件处理分页
        PageHelper.startPage(queryObject.getCurrentPage(),queryObject.getPageSize());
        // 当前页的数据
        List<Department> departments =  departmentMapper.findAll();

        return new  PageInfo(departments);
    }

    @Override
    public void deleteById(long id) {
        departmentMapper.deleteById(id);
    }

    @Override
    public Department seleteById(Long id) {
        return departmentMapper.seleteById(id);
    }

    @Override
    public void saveOrUpdate(Department department) {
        if (department.getId()!=null){
            departmentMapper.updateByPrimaryKey(department);
        }else{
            departmentMapper.insert(department);
        }
    }

    @Override
    public List<Department> listAll() {
        List<Department> departments = departmentMapper.listAll();
        return departments;
    }
}
