package cn.service.impl;

import cn.domain.Customer;
import cn.domain.Department;
import cn.mapper.CustomerMapper;
import cn.query.CustomerQueryObject;
import cn.query.QueryObject;
import cn.service.CustomerService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    CustomerMapper customerMapper;

    @Override
    public PageInfo findAll(QueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Customer> customers =  customerMapper.findAll(qo);
        return new  PageInfo(customers);
    }

    @Override
    public PageInfo findAll2(CustomerQueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Customer> customers =  customerMapper.findAll2(qo);
        return new  PageInfo(customers);
    }

    @Override
    public PageInfo findAll3(CustomerQueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Customer> customers =  customerMapper.findAll3(qo);
        return new  PageInfo(customers);
    }

    @Override
    public PageInfo findAll0(CustomerQueryObject qo, Long sId) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Customer> customers =  customerMapper.findAll0(qo,sId);
        return new  PageInfo(customers);
    }

    @Override
    public PageInfo findAll4(CustomerQueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Customer> customers =  customerMapper.findAll4(qo);
        return new  PageInfo(customers);
    }
}
