package cn.service.impl;

import cn.domain.Role;
import cn.mapper.RoleMapper;
import cn.query.QueryObject;
import cn.service.RoleService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    RoleMapper roleMapper;

    @Override
    public PageInfo findAll(QueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Role> role =  roleMapper.findAll();
        return new  PageInfo(role);
    }

    @Override
    public void deleteById(long id) {
        roleMapper.deleteById(id);
        roleMapper.deleteRelation(id);
    }

    @Override
    public Object seleteById(Long id) {
        return roleMapper.seleteById(id);
    }

    @Override
    public void saveOrUpdate(Role role , Long ids[]) {
        if (role.getId()!=null){
            roleMapper.deleteRelation(role.getId());
            roleMapper.updateByPrimaryKey(role);
        }else{
            roleMapper.insert(role);
        }

        if (ids!=null)
        {
            for (Long id : ids)
                roleMapper.insertRelation(role.getId(),id);
        }
    }

    @Override
    public List<Role> listAll() {
        return roleMapper.findAll();
    }

}
