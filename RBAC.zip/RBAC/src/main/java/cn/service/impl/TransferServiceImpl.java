package cn.service.impl;

import cn.domain.Customer;
import cn.domain.Transfer;
import cn.mapper.CustomerMapper;
import cn.mapper.TransferMapper;
import cn.query.QueryObject;
import cn.service.TransferService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransferServiceImpl implements TransferService {

    @Autowired
    TransferMapper transferMapper;

    public PageInfo findAll(QueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Transfer> transfers =  transferMapper.findAll(qo);
        return new  PageInfo(transfers);
    }
}
