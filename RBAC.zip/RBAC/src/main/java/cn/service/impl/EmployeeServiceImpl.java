package cn.service.impl;

import cn.mapper.DepartmentMapper;
import cn.mapper.RoleMapper;
import cn.service.DepartmentService;
import cn.util.UserContext;
import cn.domain.*;
import cn.mapper.EmployeeMapper;
import cn.mapper.PermissionMapper;
import cn.query.DisableException;
import cn.query.QueryObject;
import cn.service.EmployeeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl  implements EmployeeService {
    @Autowired
    private EmployeeMapper employeeMapper;
    @Autowired
    PermissionMapper permissionMapper;
    @Autowired
    RoleMapper roleMapper;

    @Override
    public PageInfo findAll(QueryObject qo) {
        // PageHelper 插件处理分页
        PageHelper.startPage(qo.getCurrentPage(),qo.getPageSize());
        // 当前页的数据
        List<Employee> employees =  employeeMapper.findAll(qo);

        return new  PageInfo(employees);
    }

    @Override
    public void deleteById(long id) {
        employeeMapper.deleteById(id);
        employeeMapper.deleteRelation(id);
    }

    @Override
    public Object seleteById(Long id) {
        return employeeMapper.seleteById(id);
    }

    @Override
    public void saveOrUpdate(Employee employee,Long ids[]) {

        if (employee.getId()!=null){
            //删除员工与角色的旧关系
            employeeMapper.deleteRelation(employee.getId());
            employeeMapper.updateByPrimaryKey(employee);
        }else{
            employeeMapper.insert(employee);
        }
        //更新员工与角色的中间表
        if (ids!=null)
        {
            for (Long id : ids)
                employeeMapper.insertRelation(employee.getId(),id);
        }
    }

    @Override
    public void checkNameAndPwd(String username, String password) {
        Employee employee = employeeMapper.selectByNameAndPwd(username,password);
        if (employee == null) {
            // 登陆失败
            throw  new DisableException("账号或者密码错误");
        }
        // 把员工信息存入session中
        UserContext.setCurrentUser(employee);

        // 把员工所拥有的权限获取到,并存入到session
        List<Permission> permissions = permissionMapper.selectPermissionsByEmpId(employee.getId());
        UserContext.setCurrentEmpPermission(permissions);
    }

    @Override
    public List<Employee> listAll() {

        Long id = roleMapper.findId();
        List<Employee> employees = employeeMapper.listAll(id);
        return employees;
    }

    @Override
    public List<Employee> listAll2() {
        Long id = roleMapper.findId();
        List<Employee> employees = employeeMapper.listAll2(id);
        return employees;
    }

    @Override
    public List<Employee> listAll3() {
        Long id = roleMapper.findId();
        List<Employee> employees = employeeMapper.listAll3(id);
        return employees;
    }

    @Override
    public List<Employee> listAll0(Long sId) {
        Long id = roleMapper.findId();
        List<Employee> employees = employeeMapper.listAll0(id,sId);
        return employees;
    }

    @Override
    public List<Employee> listAll4() {
        Long id = roleMapper.findId();
        List<Employee> employees = employeeMapper.listAll4(id);
        return employees;
    }

}

