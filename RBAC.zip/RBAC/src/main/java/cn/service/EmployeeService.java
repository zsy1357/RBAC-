package cn.service;

import cn.domain.Employee;
import cn.query.QueryObject;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface EmployeeService {
    public PageInfo findAll(QueryObject qo);

    void deleteById(long id);

    Object seleteById(Long id);

    void saveOrUpdate(Employee employee ,Long ids[]);

    void checkNameAndPwd(String username, String password);

    List<Employee> listAll();

    List<Employee> listAll2();

    List<Employee> listAll3();

    List<Employee> listAll0(Long sId);

    List<Employee> listAll4();
}
