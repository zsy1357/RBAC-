package cn.service;

import cn.domain.Department;
import cn.query.QueryObject;
import com.github.pagehelper.PageInfo;

import java.util.List;


public interface DepartmentService {
    PageInfo findAll(QueryObject queryObject);

    void deleteById(long id);

    Department seleteById(Long id);

    void saveOrUpdate(Department department);

    List<Department> listAll();
}
