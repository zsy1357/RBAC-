package cn.interceptor;

import cn.domain.Employee;
import cn.util.UserContext;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CheckLoginInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        Employee empObj = UserContext.getCurrentUser();
        if (empObj == null) {
            response.sendRedirect("/login.html");

            return false;
        }

        return true;
    }
}
