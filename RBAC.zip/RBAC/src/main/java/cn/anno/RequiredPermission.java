package cn.anno;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD) //表示该注解贴在方法上面
@Retention(RetentionPolicy.RUNTIME) //表示该注解存活到运行时期
public @interface RequiredPermission {
    //抽象方法: 注解的value属性值
    String[] value(); //存在该注解的名称 和 权限表达式
}
